# CDR Film Backend (Auto Deploy)

## Deploy via Railway (Mudah)
1. Fork/Clone repo ini ke GitHub kamu
2. Buka [Railway](https://railway.app/new)
3. Pilih "Deploy from GitHub repo"
4. Pilih repo ini → Deploy
5. Selesai! Akses backend kamu dari Railway

## Endpoint tersedia
- GET `/movies`