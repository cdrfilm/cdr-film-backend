# 🎬 CDR Film Backend

Backend sederhana untuk situs streaming film (mirip Netflix).  
Dibangun dengan Flask + SQLite + REST API.

## 🚀 Cara Deploy Otomatis (Gratis di Render.com)

1. Fork atau upload proyek ini ke GitHub
2. Buka: https://render.com
3. Pilih "New Web Service"
4. Hubungkan dengan repo ini
5. Pada `Start Command`, masukkan:
```
gunicorn app:create_app()
```

Selesai! Backend kamu akan aktif online.

## 📌 Endpoint API

| Method | Endpoint     | Fungsi              |
|--------|--------------|---------------------|
| POST   | /register    | Registrasi user     |
| POST   | /login       | Login user          |
| POST   | /film        | Tambah film baru    |
| GET    | /film        | Ambil semua film    |

