from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_cors import CORS

db = SQLAlchemy()

def create_app():
    app = Flask(__name__)
    CORS(app)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
    db.init_app(app)

    from models import User, Film

    with app.app_context():
        db.create_all()

    @app.route("/register", methods=["POST"])
    def register():
        data = request.json
        if User.query.filter_by(email=data["email"]).first():
            return jsonify({"error": "Email sudah terdaftar"}), 409
        hashed = generate_password_hash(data["password"])
        user = User(name=data["name"], email=data["email"], password=hashed)
        db.session.add(user)
        db.session.commit()
        return jsonify({"message": "Registrasi berhasil"})

    @app.route("/login", methods=["POST"])
    def login():
        data = request.json
        user = User.query.filter_by(email=data["email"]).first()
        if user and check_password_hash(user.password, data["password"]):
            return jsonify({"message": "Login sukses", "user_id": user.id})
        return jsonify({"error": "Login gagal"}), 401

    @app.route("/film", methods=["POST"])
    def add_film():
        data = request.json
        film = Film(**data)
        db.session.add(film)
        db.session.commit()
        return jsonify({"message": "Film ditambahkan"})

    @app.route("/film", methods=["GET"])
    def get_all_films():
        films = Film.query.all()
        return jsonify([film.to_dict() for film in films])

    return app

if __name__ == "__main__":
    app = create_app()
    app.run()
